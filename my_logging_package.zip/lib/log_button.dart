import 'package:flutter/material.dart';
import 'my_logger.dart';

class LogButton extends StatelessWidget {
  final String logLabel;
  final VoidCallback onPressed;
  final Widget child;

  const LogButton({
    required this.logLabel,
    required this.onPressed,
    required this.child,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        MyLogger.i("操作ログ: \$logLabel");
        onPressed();
      },
      child: child,
    );
  }
}

import 'dart:io';
import 'package:logger/logger.dart';
import 'package:path_provider/path_provider.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:archive/archive_io.dart';

enum AppEnv { dev, stg, prod }

class MyLogger {
  static late Logger _logger;
  static late Level _level;
  static late AppEnv _env;
  static File? _logFile;
  static IOSink? _sink;
  static late Directory _logDir;

  static late String _logFileName;
  static late int _maxFileSize;

  static Future<void> init({
    required AppEnv environment,
    Level logLevel = Level.info,
    String logFileName = 'log.txt',
    int maxFileSizeBytes = 1024 * 1024,
  }) async {
    _env = environment;
    _level = logLevel;
    _logFileName = logFileName;
    _maxFileSize = maxFileSizeBytes;

    _logger = Logger(
      level: _level,
      printer: PrettyPrinter(),
    );

    Directory appDocDir = await getApplicationDocumentsDirectory();
    _logDir = Directory('\${appDocDir.path}/logs');
    if (!await _logDir.exists()) {
      await _logDir.create(recursive: true);
    }

    _logFile = File('\${_logDir.path}/\$_logFileName');
    _sink = _logFile!.openWrite(mode: FileMode.append);
  }

  static void _writeToFile(String message) async {
    if (_sink == null) return;

    _sink!.writeln(message);
    await _sink!.flush();

    if (await _logFile!.length() > _maxFileSize) {
      await _rotateLog();
    }
  }

  static Future<void> _rotateLog() async {
    final now = DateTime.now();
    final newPath = '\${_logDir.path}/\${now.toIso8601String()}_\$_logFileName';
    await _sink!.close();
    await _logFile!.rename(newPath);
    _logFile = File('\${_logDir.path}/\$_logFileName');
    _sink = _logFile!.openWrite(mode: FileMode.append);
  }

  static void d(String message) {
    if (_level.index <= Level.debug.index) {
      _logger.d(message);
      _writeToFile('[DEBUG] \$message');
    }
  }

  static void i(String message) {
    if (_level.index <= Level.info.index) {
      _logger.i(message);
      _writeToFile('[INFO] \$message');
    }
  }

  static void w(String message) {
    if (_level.index <= Level.warning.index) {
      _logger.w(message);
      _writeToFile('[WARN] \$message');
    }
  }

  static void e(String message, [dynamic error, StackTrace? stackTrace]) {
    if (_level.index <= Level.error.index) {
      _logger.e(message, error, stackTrace);
      _writeToFile('[ERROR] \$message');
      if (_env == AppEnv.prod && error != null) {
        FirebaseCrashlytics.instance.recordError(error, stackTrace, reason: message);
      }
    }
  }

  static Future<File> getCompressedLogs() async {
    final encoder = GZipEncoder();
    final archiveFile = ArchiveFile.stream(
      _logFileName,
      _logFile!.lengthSync(),
      InputFileStream(_logFile!.path),
    );

    final archive = Archive();
    archive.addFile(archiveFile);

    final compressedData = encoder.encodeBuffer(archive);

    final compressedFile = File('\${_logDir.path}/logs.gz');
    await compressedFile.writeAsBytes(compressedData);
    return compressedFile;
  }
}

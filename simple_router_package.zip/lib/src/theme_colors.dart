
import 'package:flutter/material.dart';

extension CommonColors on ColorScheme {
  Color get brand => primary;
  Color get success => Colors.green;
  Color get warning => Colors.orange;
  Color get danger => Colors.red;
}

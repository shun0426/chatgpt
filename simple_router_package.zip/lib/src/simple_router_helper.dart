
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SimpleRouterHelper {
  static void goTo(BuildContext context, String location, {Object? extra}) {
    context.go(location, extra: extra);
  }

  static void pushTo(BuildContext context, String location, {Object? extra}) {
    context.push(location, extra: extra);
  }
}

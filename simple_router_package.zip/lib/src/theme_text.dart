
import 'package:flutter/material.dart';

extension CommonTextStyle on TextTheme {
  TextStyle get headline => headline6!.copyWith(fontWeight: FontWeight.bold);
  TextStyle get body => bodyText2!;
  TextStyle get caption => caption!;
}


library simple_router;

export 'src/simple_scaffold.dart';
export 'src/simple_router_helper.dart';
